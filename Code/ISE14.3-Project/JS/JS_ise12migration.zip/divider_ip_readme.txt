The following files were generated for <divider_ip> in directory 
E:\program\JS_TTL\JS:

divider_ip.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

divider_ip.edn:
   Electronic Data Netlist (EDN) file containing the information
   required to implement the module in a Xilinx (R) FPGA.

divider_ip.sym:
   Please see the core data sheet.

divider_ip.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

divider_ip.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

divider_ip.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

divider_ip.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

divider_ip.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

divider_ip_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

divider_ip_readme.txt:
   Text file indicating the files generated and how they are used.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

