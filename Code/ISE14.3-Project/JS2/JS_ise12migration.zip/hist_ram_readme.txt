The following files were generated for <hist_ram> in directory 
E:\program\JS_TTL\JS:

hist_ram.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

hist_ram.edn:
   Electronic Data Netlist (EDN) file containing the information
   required to implement the module in a Xilinx (R) FPGA.

hist_ram.sym:
   Please see the core data sheet.

hist_ram.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

hist_ram.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

hist_ram.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

hist_ram.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

hist_ram.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

hist_ram_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

hist_ram_readme.txt:
   Text file indicating the files generated and how they are used.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

