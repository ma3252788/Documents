The following files were generated for <dpram> in directory 
E:\program\JS_TTL\JS:

dpram.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

dpram.edn:
   Electronic Data Netlist (EDN) file containing the information
   required to implement the module in a Xilinx (R) FPGA.

dpram.sym:
   Please see the core data sheet.

dpram.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

dpram.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

dpram.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

dpram.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

dpram.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

dpram_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

dpram_readme.txt:
   Text file indicating the files generated and how they are used.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

