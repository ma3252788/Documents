The following files were generated for <new_gray_table> in directory 
E:\program\JS_TTL\JS:

new_gray_table.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

new_gray_table.edn:
   Electronic Data Netlist (EDN) file containing the information
   required to implement the module in a Xilinx (R) FPGA.

new_gray_table.sym:
   Please see the core data sheet.

new_gray_table.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

new_gray_table.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

new_gray_table.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

new_gray_table.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

new_gray_table.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

new_gray_table_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

new_gray_table_readme.txt:
   Text file indicating the files generated and how they are used.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

